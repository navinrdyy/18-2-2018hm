package com.hms.bean;

public class RoomBean {
	
	private String hotelId;
	private String roomId;
	private String roomNo;
	private String roomType;
	private int pricePerNight;
	private String availability;
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public int getPricePerNight() {
		return pricePerNight;
	}
	public void setPricePerNight(int pricePerNight) {
		this.pricePerNight = pricePerNight;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public RoomBean(String roomId, String roomNo, String roomType, int pricePerNight, String availability) {
		super();
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.pricePerNight = pricePerNight;
		this.availability = availability;
	}
	
	
	public RoomBean(String hotelId, String roomId, String roomNo, String roomType, int pricePerNight,
			String availability) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.pricePerNight = pricePerNight;
		this.availability = availability;
	}
	@Override
	public String toString() {
		return "RoomBean [roomId=" + roomId + ", roomNo=" + roomNo + ", roomType=" + roomType + ", pricePerNight="
				+ pricePerNight + ", availability=" + availability + "]";
	}
	
	

}
