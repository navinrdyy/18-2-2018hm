package com.hms.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomBean;

public interface IService {

	boolean adminValidation(String uName, String pass);

	List<HotelBean> getAllHotels() throws SQLException;

	List<RoomBean> getAllRooms(String hid) throws SQLException;

	int addHotel(HotelBean hBean) throws SQLException;

	HotelBean getHotelById(String htid) throws SQLException;

	int updateCity(String city1, String htid) throws SQLException;

	List<BookingBean> getHotelDetails(String hotelId) throws SQLException;

	List<BookingBean> getDetailsByDate(String bdate) throws ParseException;

	int radddetails(RoomBean rbean) throws SQLException;

	int deleteroom(String rid1);

	int updateRoomNumber(String rnum, String rid2) throws SQLException;

	int updateName(String hname, String htid);

	int updateAddress(String haddress, String htid);

	int updateDesc(String hdesc, String htid);

	int updateRpn(String hrpn, String htid);

	int updatepn1(String hpn1, String htid);

	int updateRoomType(String rtype1, String rid2);

	int updateRoomPrice(int ppn, String rid2);

	int updateRoomAvailability(String avl, String rid2);

	int updatepn2(String hpn2, String htid);

	int updateRating(String rating, String htid);

}
