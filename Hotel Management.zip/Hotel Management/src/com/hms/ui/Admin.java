package com.hms.ui;

import java.nio.channels.AsynchronousServerSocketChannel;
import java.sql.SQLDataException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomBean;
import com.hms.service.AdminServiceImpl;
import com.hms.service.IService;

public class Admin {
	static Scanner scobj = null;
	static IService serobj = null;
	static boolean result;
	public static void main(String[] args) throws SQLException, ParseException {
		HotelBean hBean=null;
		System.out.println("Admin Services");
		scobj = new Scanner(System.in);
		do {
		System.out.println("Enter your User Name");
		String uName = scobj.next();
		System.out.println("Enter your Password");
		String pass = scobj.next();
		serobj = new AdminServiceImpl();
		result = serobj.adminValidation(uName,pass);
		}while (result==false);
		int option=0;
		do {
		System.out.println("1. View Hotels");
		System.out.println("2. View Rooms from Hotel");
		System.out.println("3. Add Hotels");
		System.out.println("4. Updating Hotels");
		System.out.println("5. View Bookings of specific Hotel");
		System.out.println("6. View Bookings by date");
		System.out.println("7. exit");
			System.out.println("Enter your option");
			try {
			option = scobj.nextInt();
			}
			catch (InputMismatchException e) {
				System.out.println("OOPS entered Invalid Option\nPlease Try Again");
			}
			scobj.nextLine();
	//	}while(option<=0);		
		switch(option) {
		case 1:			
			List<HotelBean> hList = null;			
			hList = getAllHotels();
			for (HotelBean hb:hList)
			System.out.println(hb);			
			break;			
		case 2:
			boolean vRes=false;
			String hid;
			HotelBean hb = null;			
			do {
				System.out.println("Enter the Hotel Id");
				hid = scobj.next();
				AdminServiceImpl aSer = new AdminServiceImpl();
				vRes=aSer.hotelVal(hid);
			}while (vRes==false);			
			hb = getHotelById(hid);			
			if(hb!=null) {				
				List<RoomBean> rList1 = null;
				rList1 = getAllRooms(hid);
				if (rList1.isEmpty()) {
					System.out.println("Soory No rooms available in the hotel id "+hid);					
				}
				else {
					for (RoomBean obj : rList1) {
						System.out.println(obj);
					}
				}								
			}			
			else {
				System.out.println("Sorry No Hotel ID found");
			}			
			break;			
		case 3:
			String hId;
			AdminServiceImpl aSer = new AdminServiceImpl();
			do {
				System.out.println("Enter the Hotel Id");
				hId = scobj.nextLine();
				vRes=aSer.hotelVal(hId);
			}while (vRes==false);
			HotelBean hb1 = null;
			hb1 = getHotelById(hId);
			if (hb1== null) {
				String city;
				do {
					System.out.println("Enter City");
					city = scobj.nextLine();
					//AdminServiceImpl aSer = new AdminServiceImpl();
					vRes=aSer.cityVal(city);
					System.out.println("jfdnj");
				}while (vRes==false);
				String hName;
				do {
					System.out.println("Enter Hotel Name");
					hName = scobj.nextLine();
					//AdminServiceImpl aSer = new AdminServiceImpl();
					vRes=aSer.nameVal(hName);
				}while (vRes==false);
				//System.out.println("Enter ");
				System.out.println("Enter Address");
				String address = scobj.nextLine();
				System.out.println("Enter Description");
				String desc = scobj.nextLine();
				String phone1;
				String phone2;
				do {
					System.out.println("Enter Phone Number 1: ");
					phone1 = scobj.nextLine();
				
					vRes=aSer.mnoVal(phone1);
				}while (vRes==false);
				
				do {
					System.out.println("Enter Phone Number 2: ");
					phone2 = scobj.nextLine();
					//AdminServiceImpl aSer = new AdminServiceImpl();
					vRes=aSer.mnoVal(phone2);
				}while (vRes==false);

				//System.out.println("Enter Phone number 1");
				//String phone1 = scobj.nextLine();
				//System.out.println("Enter Phone number 2");
				//String phone2 = scobj.nextLine();
				System.out.println("Enter Rating");
				String rating = scobj.nextLine();
				String email;
				do {
					System.out.println("Enter Email: ");
					email= scobj.nextLine();
					vRes=aSer.emailVal(email);
				}while (vRes==false);
				
				//System.out.println("Enter Email");
				//String email = scobj.nextLine();
				System.out.println("Enter Fax");
				String fax = scobj.nextLine();
				String rate;
				do {
					System.out.println("Enter Avg Rate per Night: ");
					rate = scobj.nextLine();
					//AdminServiceImpl aSer = new AdminServiceImpl();
					vRes=aSer.rateVal(rate);
				}while (vRes==false);
				
				//System.out.println("Enter ");
				//int rate = scobj.nextInt();
				
				 hBean = new HotelBean(hId, city, hName, address, desc,rate, phone1, phone2, rating, email, fax);
				
				int status = addHotel(hBean);
				
				if (status>0) {
					System.out.println("1 Hotel inserted");
				}
				else {
					System.out.println("Data Not inserted");
				}																
			}
			else {
				System.out.println("Hotel Id Already Exists");
			}			
			break;
		case 4: 
			int opt=0;
			do {
			System.out.println("1. Update Hotel");
			System.out.println("2. Update Room in Hotel");
			System.out.println("3. exit");
			System.out.println("Enter your Option");
				try {
			 opt = scobj.nextInt();
				}catch (InputMismatchException e) {
					System.out.println("OOPS entered Incorrect Option\nPlease Try Again");
				}
				scobj.nextLine();	
		//	}while(opt<=0);
			switch (opt) {
			case 1:
				HotelBean hBean4;
				String htid;
				do {					
					System.out.println("Enter the Hotel Id");
					htid = scobj.next();
					hBean4 = getHotelById(htid);
					if (hBean4 == null) {
						System.out.println("Sorry Hotel Id is not available \n Please try again");
						//System.exit(0);
					}
					}while(hBean4==null);
                 int opt1;
               do {
				System.out.println(hBean4);
				System.out.println("What do you want to Update???");
				System.out.println("2. CITY 3.HOTEL_NAME 4.ADDRESS   "
						+ "5.DESCRIPTION 6.AVG_RATE_PERNIGHT 7.PHONE_NO1 8.PHONE_NO2 "
						+ "9.RATING 10.exit");
				System.out.println("Enter your option");
				opt1 = scobj.nextInt();
				switch(opt1){
				case 2:
					System.out.println("Enter the City Name: ");
					String city1 = scobj.next();
					int status1 = updateCity(city1, htid);
					if (status1>0) {
						//hBean.setCity(city1);
						System.out.println("city has been Updated Successfully");
					}
					else{
						System.out.println("city not updated");
					}
					break;
				case 3:
					System.out.println("enter hotel name to update");
					String hname=scobj.next();
					int status2 = updateName(hname, htid);
					if (status2>0) {
						System.out.println("hotel name has been Updated Successfully");
					}
					else{
						System.out.println("hotel name not updated");
					}
					break;
				case 4:
					System.out.println("enter new address to update");
					String haddress=scobj.next();
					int status3=updateAddress(haddress,htid);
					if (status3>0) {
						System.out.println("hotel address has been Updated Successfully");
					}
					else{
						System.out.println("hotel address not updated");
					}
					break;
				case 5:
					System.out.println("enter description to update");
					String hdesc=scobj.next();
					int status4=updateDesc(hdesc,htid);
					if (status4>0) {
						System.out.println("hotel description has been Updated Successfully");
					}
					else{
						System.out.println("hotel descriptionnot updated");
					}
					break;
				case 6:
					System.out.println("enter average rate per night to update");
					String hrpn=scobj.next();
					int status5=updateRpn(hrpn,htid);
					if (status5>0) {
						System.out.println("average rate per night has been Updated Successfully");
					}
					else{
						System.out.println("average rate per night not updated");
					}
					break;
				case 7:
					System.out.println("enter phone number 1 to update");
					String hpn1=scobj.next();
					int status6=updatepn1(hpn1,htid);
					if (status6>0) {
						System.out.println(" phone number 1 has been Updated Successfully");
					}
					else{
						System.out.println(" phone number 1 not updated");
					}
					break;
				case 8:
					System.out.println("enter phone number 2 to update");
					String hpn2=scobj.next();
					int status7=updatepn2(hpn2,htid);
					if (status7>0) {
						System.out.println(" phone number 2 has been Updated Successfully");
					}
					else{
						System.out.println(" phone number 2 not updated");
					}
					break;
				case 9:
					System.out.println("enter new rating to update");
					String rating=scobj.next();
					int status8=updateRating(rating,htid);
					if (status8>0) {
						System.out.println(" rating has been Updated Successfully");
					}
					else{
						System.out.println(" rating not updated");
					}
					break;
				case 10:
					System.exit(0);
					default:
						System.out.println("you entered wrong option");
				/*System.out.println("enter 1 to update another item");
				int do1=scobj.nextInt();
				case4=aSer.docase(do1);
				while(case4==false);*/
               }
			}while(opt1!=10);
               break;
			case 2:
				int opt2;
				System.out.println("enter hotel id ");
				String htid1=scobj.next();
				do {
				System.out.println("1.add rooms");
				System.out.println("2.delete rooms");
				System.out.println("3. modify room info");
				System.out.println("4.exit");
				System.out.println("Enter your option");
				opt2 = scobj.nextInt();
				switch(opt2){
				case 1:
					System.out.println("enter room id");
					String rid=scobj.next();
					System.out.println("enter room number");
					String rnum=scobj.next();
					System.out.println("enter room type");
					String rtype=scobj.next();
					System.out.println("rate per night");
					int rate1=scobj.nextInt();
					System.out.println("availability");
					String avail=scobj.next();
					RoomBean rbean=new RoomBean(htid1,rid, rnum, rtype,rate1, avail);
					int rstatus=radddetails(rbean);
					if(rstatus>0) {
					System.out.println("room added successfully");
					}
					else {
						System.out.println("try again");
					}
					break;
				case 2:
					System.out.println("enter room id");
					String rid1=scobj.next();
					int rstatus1=deleteroom(rid1);
					if(rstatus1>0)
						System.out.println("room deleted successfully");
					else {
						System.out.println("room");
					}
					break;
				case 3:
				System.out.println("enter room id to modify room info");
				String rid2=scobj.next();
				HotelBean hBean5 = getHotelById(rid2);
				System.out.println(hBean5);
				
				System.out.println("What do you want to Update???");
				System.out.println("1.room number 2.room type 3.price 4.availability   ");
				System.out.println("Enter your option");
				int opt3 = scobj.nextInt();
				switch(opt3){
					case 1:
					System.out.println("enter room number");
					String rnum1=scobj.next();
					int rstatus2=updateRoomNumber(rnum1,rid2);
					if(rstatus2>0) {
						System.out.println("room number has been successfully updated");
					}
					else {
						System.out.println("try again");
					}
					break;
					case 2:
						System.out.println("enter type of room to modify");
						String rtype1=scobj.next();
						int rstatus3=updateRoomType(rtype1,rid2);
						if(rstatus3>0) {
							System.out.println("room type has been successfully updated");
						}
						else {
							System.out.println("try again");
						}
						break;
					case 3:
						System.out.println("enter new price to modify");
						int ppn=scobj.nextInt();
						int rstatus4=updateRoomPrice(ppn,rid2);
						if(rstatus4>0) {
							System.out.println("price has been successfully updated");
						}
						else {
							System.out.println("try again");
						}
						break;
					case 4:
						System.out.println("enter new availability to modify");
						String avl=scobj.next();
						int rstatus5=updateRoomAvailability(avl,rid2);
						if(rstatus5>0) {
							System.out.println("availability has been successfully updated");
						}
						else {
							System.out.println("try again");
						}
						break;
				}
				case 4:
					System.out.println("****EXIT****");
					System.exit(0);
					default:
						System.out.println("entered option is incorrect");
				}
				}while(opt2!=4);
				break;	
			case 3:
				System.out.println("THANK YOU");
				System.exit(0);
			default:
				System.out.println("please enter correct option");
			}
		}while(opt!=3);
		case 5:
			AdminServiceImpl aServ= new AdminServiceImpl();
			String hotelId;
			boolean vRes1=false;
			do {
				System.out.println("Enter hotel id");
				hotelId=scobj.next();	
				vRes1 = aServ.hotelVal(hotelId);
			}while(vRes1==false);
			
			hb = getHotelById(hotelId);
			if (hb!=null) {				
				List<BookingBean> b1=getHotelDetails(hotelId);
				if(b1.isEmpty()) {
					System.out.println("Sorry No bookings for this hotel");					
				}
				else {
					for (BookingBean b:b1)
						System.out.println(b1);
				}
			}
			else {
				System.out.println("Hotel Not Found");
			}			
			
		
			break;
		case 6:
			String bdate;
			AdminServiceImpl aSer1 = new AdminServiceImpl();
			do{
				System.out.println("enter From date");
				bdate=scobj.next();
				vRes=aSer1.dateVal(bdate);

			}while(vRes==false);
			try {
				
				List<BookingBean> b2=getDetailsByDate(bdate);
				if (b2.isEmpty()) {
					System.out.println("NO Bookings Found for "+bdate);
				}
				else {
					for(BookingBean b: b2)
						System.out.println(b2);
				}
			}
			catch (Exception e) {
				System.out.println("Date is not valid");
				//System.out.println(e.getMessage());
			}
			break;
		case 7:
			System.out.println("THANK YOU!!!");
			System.exit(0);
			break;
			default:
				System.out.println("entered option is incorrect");
				break;	
			}
}while(option!=7);
}
	private static int updateRating(String rating, String htid) {
		serobj = new AdminServiceImpl();
		return serobj.updateRating(rating,htid);
	}		
	private static int updatepn2(String hpn2, String htid) {
		serobj = new AdminServiceImpl();
		return serobj.updatepn2(hpn2,htid);
	}
	private static int updateRoomAvailability(String avl, String rid2) {
		serobj = new AdminServiceImpl();
		return serobj.updateRoomAvailability(avl,rid2);
	}
	private static int updateRoomPrice(int ppn, String rid2) {
		serobj = new AdminServiceImpl();
		return serobj.updateRoomPrice(ppn,rid2);
	}
	private static int updateRoomType(String rtype1, String rid2) {
		serobj = new AdminServiceImpl();
		return serobj.updateRoomType(rtype1,rid2);
	}
		private static int updatepn1(String hpn1, String htid) {
		serobj = new AdminServiceImpl();
		return serobj.updatepn1(hpn1,htid);
	}
	private static int updateRpn(String hrpn, String htid) {
		serobj = new AdminServiceImpl();
		return serobj.updateRpn(hrpn,htid);
	}
	



	private static int updateDesc(String hdesc, String htid) {
		serobj = new AdminServiceImpl();
		return serobj.updateDesc(hdesc,htid);
	}
	private static int updateAddress(String haddress, String htid) {
		// TODO Auto-generated method stub
		serobj = new AdminServiceImpl();
		return serobj.updateAddress(haddress,htid);
	}
	private static int updateName(String hname, String htid) {
		// TODO Auto-generated method stub
		serobj = new AdminServiceImpl();
		return serobj.updateName(hname,htid);
	}


	private static int updateRoomNumber(String rnum, String rid2) throws SQLException {
		// TODO Auto-generated method stub
		serobj = new AdminServiceImpl();
		return serobj.updateRoomNumber(rnum,rid2);
	}
	private static int deleteroom(String rid1) {
		// TODO Auto-generated method stub
		serobj = new AdminServiceImpl();
		return serobj.deleteroom(rid1);
	}
	private static int radddetails(RoomBean rbean) throws SQLException {
		// TODO Auto-generated method stub
		serobj = new AdminServiceImpl();
		return serobj.radddetails(rbean);
	}
	private static List<BookingBean> getDetailsByDate(String bdate) throws ParseException {
		serobj=new AdminServiceImpl();
		return serobj.getDetailsByDate(bdate);
	}
	private static List<BookingBean> getHotelDetails(String hotelId) throws SQLException {
		// TODO Auto-generated method stub
		serobj=new AdminServiceImpl();
		return serobj.getHotelDetails(hotelId);
	}
	private static int updateCity(String city1, String htid) throws SQLException {
		serobj = new AdminServiceImpl();
		return serobj.updateCity(city1,htid);
	}
	private static HotelBean getHotelById(String htid) throws SQLException {
		serobj = new AdminServiceImpl();
		return serobj.getHotelById(htid);
	}
	private static int addHotel(HotelBean hBean) throws SQLException {
		serobj = new AdminServiceImpl();
		return serobj.addHotel(hBean);
	}
	private static List<RoomBean> getAllRooms(String hid) throws SQLException {
		serobj = new AdminServiceImpl();
		return serobj.getAllRooms(hid);
	}
	private static List<HotelBean> getAllHotels() throws SQLException {
		serobj = new AdminServiceImpl();
		return serobj.getAllHotels();
	}

}
